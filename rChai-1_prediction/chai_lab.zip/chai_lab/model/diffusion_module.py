import torch
import torch.nn.functional as F
from torch import Tensor

# Define constants from the trace
c0 = 0.25
c1 = 1 # Often used for multiplication, essentially identity
c2 = 6.283185307179586 # 2 * pi
c3 = 256.0
c4 = 2 # Used for division (e.g., halving for split)
c5 = 16 # Number of heads / pair dim?
c6 = 16.0
# Epsilon for LayerNorm, assuming standard value
DEFAULT_LAYER_NORM_EPS = 1e-5
HIGH_EPS_LAYER_NORM = 0.1 # Epsilon used in atom attention LN
# Scale factor for attention
ATTN_SCALE_FROM_TRACE = 0.3799178428257963 # Using trace value


class custom_diffusion_module(torch.nn.Module):
    def __init__(self, diffusion_module):
        super().__init__()
        # Copy necessary module references
        self.diffusion_conditioning = diffusion_module.diffusion_conditioning
        self.atom_attention_encoder = diffusion_module.atom_attention_encoder
        self.diffusion_transformer = diffusion_module.diffusion_transformer
        self.atom_attention_decoder = diffusion_module.atom_attention_decoder
        self.post_attn_layernorm = diffusion_module.post_attn_layernorm
        self.post_atom_cond_layernorm = diffusion_module.post_atom_cond_layernorm
        self.structure_cond_to_token_structure_proj = diffusion_module.structure_cond_to_token_structure_proj

    def forward(self,
        token_single_initial_repr: Tensor, # [1, 256, 384]
        token_pair_initial_repr: Tensor,   # [1, 256, 256, 256]
        token_single_trunk_repr: Tensor,   # [1, 256, 384]
        token_pair_trunk_repr: Tensor,     # [1, 256, 256, 256]
        atom_single_input_feats: Tensor,   # [1, 5888, 128]
        atom_block_pair_input_feats: Tensor, # [1, 184, 32, 128, 16]
        atom_single_mask: Tensor,          # [1, 5888] bool
        atom_block_pair_mask: Tensor,      # [1, 184, 32, 128] bool
        token_single_mask: Tensor,         # [1, 256] bool
        block_indices_h: Tensor,           # [184, 32] int64
        block_indices_w: Tensor,           # [184, 128] int64
        atom_noised_coords: Tensor,        # [1, 5, 5888, 3]
        noise_sigma: Tensor,               # [1, 5]
        atom_token_indices: Tensor         # [1, 5888] int64
    ) -> Tensor:

        # Device and constants
        device = token_single_initial_repr.device
        num_diff_samples = noise_sigma.shape[1] # 5
        num_tokens = token_single_initial_repr.shape[1] # 256
        num_atoms = atom_single_input_feats.shape[1] # 5888
        batch_size = 1 # Assuming B=1

        # --- 1. Diffusion Conditioning ---
        diffusion_conditioning = self.diffusion_conditioning

        # Process Pair Representation (Using module calls as in refined trace)
        token_p_combined = torch.cat([token_pair_trunk_repr, token_pair_initial_repr], dim=-1)
        token_p_proj = diffusion_conditioning.token_pair_proj(token_p_combined) # Implicit LN + Linear
        token_p_trans1_out = diffusion_conditioning.pair_trans1(token_p_proj)     # Implicit LN + Gated MLP
        token_p_trans_sum1 = token_p_proj + token_p_trans1_out
        token_p_trans2_out = diffusion_conditioning.pair_trans2(token_p_trans_sum1) # Implicit LN + Gated MLP
        token_p_trans_sum2 = token_p_trans_sum1 + token_p_trans2_out
        token_p_cond = diffusion_conditioning.pair_ln(token_p_trans_sum2)         # Module call (LN)

        # Process Single Representation (Using module calls)
        token_s_combined = torch.cat([token_single_initial_repr, token_single_trunk_repr], dim=-1)
        token_s_proj = diffusion_conditioning.token_in_proj(token_s_combined) # Implicit LN + Linear

        # Time/Noise Embedding (Explicit ops as in trace)
        log_sigma = torch.log(torch.clamp_min(noise_sigma, 1.19209e-07)) * c0
        fourier_in = log_sigma.view(num_diff_samples, 1)
        _fe_weights = diffusion_conditioning.fourier_embedding.weights
        _fe_bias = diffusion_conditioning.fourier_embedding.bias
        fourier_feats = torch.add(torch.mul(fourier_in, _fe_weights), _fe_bias)
        fourier_feats = torch.cos(torch.mul(fourier_feats, c2))
        time_cond_emb = fourier_feats.unsqueeze(1) # [5, 1, 256]

        # --- CORRECTED Fourier projection (Using sequential module calls) ---
        _fourier_proj_ln = getattr(diffusion_conditioning.fourier_proj, "0")
        _fourier_proj_linear = getattr(diffusion_conditioning.fourier_proj, "1")
        _norm_fourier_emb = _fourier_proj_ln(time_cond_emb) # Apply LayerNorm module
        time_cond_proj = _fourier_proj_linear(_norm_fourier_emb) # Apply Linear module
        # time_cond_proj shape: [5, 1, 384]

        # Combine Single and Time conditioning
        token_s_proj_expanded = token_s_proj.unsqueeze(1)
        time_cond_proj_expanded = time_cond_proj.unsqueeze(0)
        token_s_cond_input = token_s_proj_expanded + time_cond_proj_expanded

        # Apply Single Transitions (Using module calls, passing time_cond for AdaLN)
        # time_cond_adaln = time_cond_proj_expanded.squeeze(2)
        token_s_trans1_out = diffusion_conditioning.single_trans1(token_s_cond_input) # Implicit LN + Gated MLP
        token_s_trans_sum1 = token_s_cond_input + token_s_trans1_out
        token_s_trans2_out = diffusion_conditioning.single_trans2(token_s_trans_sum1) # Implicit LN + Gated MLP
        token_s_trans_sum2 = token_s_trans_sum1 + token_s_trans2_out
        # Single LN (Using module call)
        token_s_cond = diffusion_conditioning.single_ln(token_s_trans_sum2) # Module call (LN)

        # --- 2. Atom Attention Encoder ---
        # (Rest of the code remains the same as the previous version,
        # as it primarily used module calls or explicit low-level ops
        # consistent with the refined trace for the core loops)
        atom_attention_encoder = self.atom_attention_encoder

        # Scale noised coordinates (Explicit ops)
        sigma_bc = noise_sigma.view(batch_size, num_diff_samples, 1, 1) # [1, 5, 1, 1]
        sigma_sq = sigma_bc ** c4
        scale_factor = (sigma_sq + c3)**(-0.5) # [1, 5, 1, 1]
        scaled_noised_coords = atom_noised_coords * scale_factor # [1, 5, 5888, 3]

        # Initial Atom Single Representation (Using module calls where appropriate)
        atom_s_cond_proj = atom_attention_encoder.to_atom_cond(atom_single_input_feats) # Module call (Linear)
        token_s_trunk_proj = atom_attention_encoder.token_to_atom_single(token_single_trunk_repr) # Module call (LN+Linear)
        batch_indices = torch.arange(batch_size, device=device).unsqueeze(1)
        atom_token_features = token_s_trunk_proj[batch_indices, atom_token_indices].squeeze(0) # [5888, 128]
        atom_s_repr_0 = atom_s_cond_proj.squeeze(0) + atom_token_features #[5888, 128]
        # Explicit LN as in trace (no weight/bias specified)
        atom_s_repr_ln = F.layer_norm(atom_s_repr_0, [atom_s_repr_0.shape[-1]], eps=DEFAULT_LAYER_NORM_EPS) #[5888, 128]

        # Position Embedding (Using module call)
        pos_embed = atom_attention_encoder.prev_pos_embed(
            scaled_noised_coords.reshape(-1, 3) # Flatten B,S,N dims
        ).view(batch_size, num_diff_samples, num_atoms, -1) # [1, 5, 5888, 128]

        # Add Position Embedding (Explicit op)
        atom_s_repr_enc = atom_s_repr_ln.unsqueeze(0).unsqueeze(1) + pos_embed # [1, 5, 5888, 128]

        # Initial Atom Pair Representation (Using module calls where appropriate)
        token_p_for_atom = atom_attention_encoder.token_pair_to_atom_pair(token_p_cond) # Module call (LN+Linear)
        # pair_update_block (Using module call)
        atom_p_repr_enc = atom_attention_encoder.pair_update_block(
            atom_s_repr_enc, atom_block_pair_input_feats, token_p_for_atom,
            block_indices_h, block_indices_w, atom_token_indices
        ) # [1, 5, 184, 32, 128, 16]

        # Prepare inputs for Atom Encoder loop
        atom_s_enc = atom_s_repr_enc.view(num_diff_samples, num_atoms, -1) # [5, 5888, 128]
        atom_p_enc = atom_p_repr_enc.squeeze(0) # [5, 184, 32, 128, 16]
        atom_s_cond_adaln = atom_s_repr_ln.expand(num_diff_samples, -1, -1) # [5, 5888, 128]
        atom_single_mask_expanded = atom_single_mask.squeeze(0).expand(num_diff_samples, -1) # [5, 5888] bool
        atom_block_pair_mask_expanded = atom_block_pair_mask.squeeze(0).unsqueeze(0).expand(num_diff_samples, -1, -1, -1) #[5, 184, 32, 128] bool

        # Calculate relative indices (Explicit ops)
        block_size_q = block_indices_h.shape[1] # 32
        block_size_kv = block_indices_w.shape[1] # 128
        q_block_indices = torch.arange(num_atoms, device=device).view(-1, block_size_q)
        first_q_idx_in_block = q_block_indices[:, 0:1]
        offset = first_q_idx_in_block - (block_size_kv // c4)
        rel_kv_indices = torch.arange(block_size_kv, device=device) + offset
        rel_kv_indices = torch.remainder(rel_kv_indices, num_atoms)

        # --- Atom Encoder Transformer Loop (Explicit ops following trace) ---
        encoder_transformer = atom_attention_encoder.atom_transformer.local_diffn_transformer
        for i in range(len(encoder_transformer.local_attentions)):
            attn_layer = getattr(encoder_transformer.local_attentions, str(i))
            trans_layer = getattr(encoder_transformer.transitions, str(i))
            pair_bias_ln = getattr(encoder_transformer.blocked_pairs2blocked_bias, "0")
            pair_bias_linear = getattr(encoder_transformer.blocked_pairs2blocked_bias, "1")

            # Generate pair bias
            pair_bias_norm = F.layer_norm(atom_p_enc, [c5], weight=pair_bias_ln.weight, bias=pair_bias_ln.bias, eps=DEFAULT_LAYER_NORM_EPS)
            head_bias_weights = pair_bias_linear.weight[i]
            pair_bias = torch.einsum('...c, hc -> ...h', pair_bias_norm, head_bias_weights).permute(0, 4, 1, 2, 3)
            pair_bias = pair_bias.masked_fill(~atom_block_pair_mask_expanded.unsqueeze(1), -1e4)

            atom_s_enc = atom_s_enc * atom_single_mask_expanded.unsqueeze(-1).float()

            # --- Attention Sub-block ---
            residual = atom_s_enc
            # AdaLN norm
            _attn_ln_s_merged_w = attn_layer.single_layer_norm.lin_s_merged.weight
            scale_shift_attn = F.linear(atom_s_cond_adaln, _attn_ln_s_merged_w.t())
            scale_attn, shift_attn = torch.chunk(scale_shift_attn, c4, dim=-1)
            atom_s_norm = F.layer_norm(atom_s_enc, [atom_s_enc.shape[-1]], eps=HIGH_EPS_LAYER_NORM) # No weight/bias
            atom_s_norm = atom_s_norm * (scale_attn + c1) + shift_attn

            # QKV proj
            qkv_w = attn_layer.to_qkv.weight
            qkv_flat = F.linear(atom_s_norm, qkv_w.view(-1, qkv_w.shape[-1]).t())
            qkv = qkv_flat.view(num_diff_samples, num_atoms, 3, attn_layer.heads, -1).permute(2, 0, 3, 1, 4)
            q, k, v = qkv[0], qkv[1], qkv[2]
            q = q + attn_layer.q_bias.unsqueeze(0).unsqueeze(2)
            q_block = q.view(num_diff_samples, attn_layer.heads, -1, block_size_q, q.shape[-1])

            # Gather K, V
            k_idx = rel_kv_indices.expand(num_diff_samples, attn_layer.heads, -1, -1).unsqueeze(-1).expand(-1, -1, -1, -1, k.shape[-1])
            k_rel = torch.gather(k, 2, k_idx)
            v_idx = rel_kv_indices.expand(num_diff_samples, attn_layer.heads, -1, -1).unsqueeze(-1).expand(-1, -1, -1, -1, v.shape[-1])
            v_rel = torch.gather(v, 2, v_idx)
            k_block = k_rel.view(num_diff_samples, attn_layer.heads, -1, block_size_kv, k.shape[-1])
            v_block = v_rel.view(num_diff_samples, attn_layer.heads, -1, block_size_kv, v.shape[-1])
            pair_bias_for_attn = pair_bias.view(num_diff_samples, attn_layer.heads, -1, block_size_q, block_size_kv)

            # SDPA (Explicit Matmul/Softmax)
            attn_weights = torch.matmul(q_block * ATTN_SCALE_FROM_TRACE, k_block.transpose(-1, -2))
            attn_weights = attn_weights + pair_bias_for_attn
            attn_weights = F.softmax(attn_weights, dim=-1)
            attn_output_block = torch.matmul(attn_weights, v_block)

            # Output proj + Gate
            attn_output = attn_output_block.permute(0, 2, 3, 1, 4).reshape(num_diff_samples, num_atoms, -1)
            _attn_out_proj_w = attn_layer.out_proj.weight
            _attn_out_proj_b = attn_layer.out_proj.bias
            attn_output_proj = F.linear(attn_output, _attn_out_proj_w.t()) # Project output
            attn_output_plus_bias = attn_output_proj + _attn_out_proj_b
            gate_from_trace = torch.sigmoid(attn_output_plus_bias)
            atom_s_enc = residual + attn_output * gate_from_trace # Multiply original output by gate

            # --- Transition Sub-block ---
            residual = atom_s_enc
            # AdaLN norm
            _trans_ln_s_merged_w = trans_layer.ada_ln.lin_s_merged.weight
            scale_shift_trans = F.linear(atom_s_cond_adaln, _trans_ln_s_merged_w.t())
            scale_trans, shift_trans = torch.chunk(scale_shift_trans, c4, dim=-1)
            atom_s_norm = F.layer_norm(atom_s_enc, [atom_s_enc.shape[-1]], eps=HIGH_EPS_LAYER_NORM) # No weight/bias
            atom_s_norm = atom_s_norm * (scale_trans + c1) + shift_trans

            # Gated MLP
            _trans_lin_a_w = trans_layer.linear_a_nobias_double.weight
            _trans_lin_b_w = trans_layer.linear_b_nobias.weight
            _trans_lin_s_w = trans_layer.linear_s_biasinit_m2.weight
            _trans_lin_s_b = trans_layer.linear_s_biasinit_m2.bias
            mlp_ab = F.linear(atom_s_norm, _trans_lin_a_w.t())
            mlp_a, mlp_b = torch.chunk(mlp_ab, c4, dim=-1)
            mlp_hidden = F.silu(mlp_a) * mlp_b
            mlp_out = F.linear(mlp_hidden, _trans_lin_b_w.t())
            gate_trans_cond = F.linear(atom_s_cond_adaln, _trans_lin_s_w.t(), _trans_lin_s_b)
            gate_trans = torch.sigmoid(gate_trans_cond)
            trans_output = mlp_out * gate_trans
            atom_s_enc = residual + trans_output

            atom_s_enc = atom_s_enc * atom_single_mask_expanded.unsqueeze(-1).float()

        # --- Post Encoder Processing ---
        atom_s_repr_final_enc = atom_s_enc.view(batch_size, num_diff_samples, num_atoms, -1)
        # to_token_single (Relu + Linear)
        _to_token_linear = getattr(atom_attention_encoder.to_token_single, "0") # Assuming it's a Linear layer now
        structure_cond_feats = F.relu(F.linear(atom_s_repr_final_enc, _to_token_linear.weight)) # Using Linear's weight

        # Aggregate atom features (Explicit scatter)
        token_indices_scat = atom_token_indices.squeeze(0).expand(num_diff_samples, -1)
        atom_mask_scat = atom_single_mask_expanded
        structure_cond_feats_scat = structure_cond_feats.view(num_diff_samples, num_atoms, -1)
        pooled_structure_cond = torch.zeros(num_diff_samples, num_tokens, 768, device=device, dtype=structure_cond_feats.dtype)
        counts = torch.zeros(num_diff_samples, num_tokens, device=device, dtype=torch.float32)
        token_indices_scat_exp = token_indices_scat.unsqueeze(-1).expand(-1, -1, 768)
        structure_cond_feats_masked = structure_cond_feats_scat * atom_mask_scat.unsqueeze(-1).float()
        pooled_structure_cond.scatter_add_(1, token_indices_scat_exp, structure_cond_feats_masked)
        counts.scatter_add_(1, token_indices_scat, atom_mask_scat.float())
        pooled_structure_cond = pooled_structure_cond / torch.clamp(counts.unsqueeze(-1), min=1)
        pooled_structure_cond = pooled_structure_cond.unsqueeze(0)

        # Final structure conditioning projection (Using module call) and addition
        structure_cond_proj = self.structure_cond_to_token_structure_proj(token_s_cond) # Module call (Linear)
        structure_cond = pooled_structure_cond + structure_cond_proj

        # --- 3. Diffusion Transformer (16 blocks, Explicit ops following trace) ---
        diffusion_transformer = self.diffusion_transformer
        token_s_diff = structure_cond
        token_p_diff = token_p_cond.unsqueeze(1)
        token_mask_for_attn = (token_single_mask.unsqueeze(-1) & token_single_mask.unsqueeze(-2)).unsqueeze(1).unsqueeze(1)
        time_cond_adaln_diff = time_cond_proj.unsqueeze(0).unsqueeze(2) # [1, 5, 1, 384]

        for i in range(16):
            block = getattr(diffusion_transformer.blocks, str(i))
            residual_s = token_s_diff

            # Attention LN + AdaLN
            _norm_in_ln_w = block.norm_in.lin_s_merged.weight
            scale_shift_norm = F.linear(time_cond_adaln_diff, _norm_in_ln_w.t())
            scale_norm, shift_norm = torch.chunk(scale_shift_norm, c4, dim=-1)
            # Explicit LayerNorm with high epsilon (no weight/bias)
            token_s_norm = F.layer_norm(token_s_diff, [token_s_diff.shape[-1]], eps=HIGH_EPS_LAYER_NORM)
            token_s_norm = token_s_norm * (scale_norm + c1) + shift_norm

            # QKV Projection
            _to_qkv_w = block.to_qkv.weight
            qkv_diff_flat = F.linear(token_s_norm, _to_qkv_w.t())
            qkv_diff = qkv_diff_flat.view(batch_size, num_diff_samples, num_tokens, block.heads, 3 * block.dim_head).permute(0, 3, 1, 2, 4)
            q_diff, k_diff, v_diff = torch.chunk(qkv_diff, 3, dim=-1)
            q_diff = q_diff + block.q_bias.unsqueeze(0).unsqueeze(2).unsqueeze(3)

            # Pair Bias
            _pair_ln_w = block.pair_layer_norm.weight
            _pair_ln_b = block.pair_layer_norm.bias
            _pair_linear_w = block.pair_linear.weight
            # Explicit LayerNorm + Linear
            pair_bias_norm = F.layer_norm(token_p_diff, [_pair_ln_w.shape[0]], _pair_ln_w, _pair_ln_b, DEFAULT_LAYER_NORM_EPS)
            pair_bias = F.linear(pair_bias_norm, _pair_linear_w.t()).permute(0, 4, 1, 2, 3)
            pair_bias = pair_bias.masked_fill(~token_mask_for_attn, -1e4)

            # Attention
            attn_weights_diff = torch.matmul(q_diff * ATTN_SCALE_FROM_TRACE, k_diff.transpose(-1, -2))
            attn_weights_diff = attn_weights_diff + pair_bias
            attn_weights_diff = F.softmax(attn_weights_diff, dim=-1)
            attn_output_diff = torch.matmul(attn_weights_diff, v_diff)
            attn_output_diff = attn_output_diff.permute(0, 2, 3, 1, 4).reshape(batch_size, num_diff_samples, num_tokens, -1)

            # Output Projection + Gating
            _out_w = block.to_out.weight
            attn_output_proj = F.linear(attn_output_diff, _out_w.t())
            _gate_proj_w = getattr(block.gate_proj,"0").weight
            _gate_proj_b = getattr(block.gate_proj,"0").bias
            gate_attn_linear = F.linear(time_cond_adaln_diff, _gate_proj_w.t(), _gate_proj_b)
            attn_gated = attn_output_proj * torch.sigmoid(gate_attn_linear)
            token_s_diff = residual_s + attn_gated

            # Transition LN + AdaLN
            residual_s = token_s_diff
            _trans_ln_s_merged_w = block.transition.ada_ln.lin_s_merged.weight
            scale_shift_trans = F.linear(time_cond_adaln_diff, _trans_ln_s_merged_w.t())
            scale_trans, shift_trans = torch.chunk(scale_shift_trans, c4, dim=-1)
            # Explicit LayerNorm with high epsilon (no weight/bias)
            token_s_norm = F.layer_norm(token_s_diff, [token_s_diff.shape[-1]], eps=HIGH_EPS_LAYER_NORM)
            token_s_norm = token_s_norm * (scale_trans + c1) + shift_trans

            # Transition Gated MLP
            _trans_lin_a_w = block.transition.linear_a_nobias_double.weight
            _trans_lin_b_w = block.transition.linear_b_nobias.weight
            _trans_lin_s_w = block.transition.linear_s_biasinit_m2.weight
            _trans_lin_s_b = block.transition.linear_s_biasinit_m2.bias
            mlp_ab_diff = F.linear(token_s_norm, _trans_lin_a_w.t())
            mlp_a_diff, mlp_b_diff = torch.chunk(mlp_ab_diff, c4, dim=-1)
            mlp_hidden_diff = F.silu(mlp_a_diff) * mlp_b_diff
            mlp_out_diff = F.linear(mlp_hidden_diff, _trans_lin_b_w.t())
            gate_trans_cond = F.linear(time_cond_adaln_diff, _trans_lin_s_w.t(), _trans_lin_s_b)
            gate_trans = torch.sigmoid(gate_trans_cond)
            trans_output = mlp_out_diff * gate_trans
            token_s_diff = residual_s + trans_output

        # Post Transformer LN (Using module call)
        token_s_final = self.post_attn_layernorm(token_s_diff)

        # --- 4. Atom Attention Decoder ---
        atom_attention_decoder = self.atom_attention_decoder
        # Post Atom Cond LN (Using module call)
        atom_s_cond_final = self.post_atom_cond_layernorm(atom_s_repr_ln)

        # Project final token state to atom space (Using module call)
        token_s_dec_proj = atom_attention_decoder.token_to_atom(token_s_final)

        # Gather token features per atom
        token_s_dec_proj_flat = token_s_dec_proj.view(num_diff_samples, num_tokens, -1)
        atom_token_features_dec = torch.stack([
             token_s_dec_proj_flat[s_idx, atom_token_indices.squeeze(0), :] for s_idx in range(num_diff_samples)
        ], dim=0)

        # Add decoder token features to ENCODER output
        atom_s_dec_input = atom_s_enc + atom_token_features_dec

        # Prepare conditioning signal for AdaLN in decoder
        atom_s_cond_dec = atom_s_cond_final.expand(num_diff_samples, -1, -1)

        # --- Atom Decoder Transformer Loop (Explicit ops following trace) ---
        decoder_transformer = atom_attention_decoder.atom_transformer.local_diffn_transformer
        atom_s_dec = atom_s_dec_input

        for i in range(len(decoder_transformer.local_attentions)): # Should be 3 iterations
            attn_layer = getattr(decoder_transformer.local_attentions, str(i))
            trans_layer = getattr(decoder_transformer.transitions, str(i))
            pair_bias_ln_dec = getattr(decoder_transformer.blocked_pairs2blocked_bias, "0")
            pair_bias_linear_dec = getattr(decoder_transformer.blocked_pairs2blocked_bias, "1")

            # Pair bias (uses encoder's atom_p_enc)
            pair_bias_norm = F.layer_norm(atom_p_enc, [c5], weight=pair_bias_ln_dec.weight, bias=pair_bias_ln_dec.bias, eps=DEFAULT_LAYER_NORM_EPS)
            head_bias_weights_dec = pair_bias_linear_dec.weight[i]
            pair_bias = torch.einsum('...c, hc -> ...h', pair_bias_norm, head_bias_weights_dec).permute(0, 4, 1, 2, 3)
            pair_bias = pair_bias.masked_fill(~atom_block_pair_mask_expanded.unsqueeze(1), -1e4)

            atom_s_dec = atom_s_dec * atom_single_mask_expanded.unsqueeze(-1).float()

            # --- Attention Sub-block (Decoder) ---
            residual = atom_s_dec
            # AdaLN norm
            _attn_ln_s_merged_w_dec = attn_layer.single_layer_norm.lin_s_merged.weight
            scale_shift_attn_dec = F.linear(atom_s_cond_dec, _attn_ln_s_merged_w_dec.t())
            scale_attn_dec, shift_attn_dec = torch.chunk(scale_shift_attn_dec, c4, dim=-1)
            atom_s_norm_dec = F.layer_norm(atom_s_dec, [atom_s_dec.shape[-1]], eps=HIGH_EPS_LAYER_NORM) # No weight/bias
            atom_s_norm_dec = atom_s_norm_dec * (scale_attn_dec + c1) + shift_attn_dec

            # QKV proj
            qkv_dec_w = attn_layer.to_qkv.weight
            qkv_dec_flat = F.linear(atom_s_norm_dec, qkv_dec_w.view(-1, qkv_dec_w.shape[-1]).t())
            qkv_dec = qkv_dec_flat.view(num_diff_samples, num_atoms, 3, attn_layer.heads, -1).permute(2, 0, 3, 1, 4)
            q_dec, k_dec, v_dec = qkv_dec[0], qkv_dec[1], qkv_dec[2]
            q_dec = q_dec + attn_layer.q_bias.unsqueeze(0).unsqueeze(2)
            q_block_dec = q_dec.view(num_diff_samples, attn_layer.heads, -1, block_size_q, q_dec.shape[-1])

            # Gather K, V
            k_idx_dec = rel_kv_indices.expand(num_diff_samples, attn_layer.heads, -1, -1).unsqueeze(-1).expand(-1, -1, -1, -1, k_dec.shape[-1])
            k_rel_dec = torch.gather(k_dec, 2, k_idx_dec)
            v_idx_dec = rel_kv_indices.expand(num_diff_samples, attn_layer.heads, -1, -1).unsqueeze(-1).expand(-1, -1, -1, -1, v_dec.shape[-1])
            v_rel_dec = torch.gather(v_dec, 2, v_idx_dec)
            k_block_dec = k_rel_dec.view(num_diff_samples, attn_layer.heads, -1, block_size_kv, k_dec.shape[-1])
            v_block_dec = v_rel_dec.view(num_diff_samples, attn_layer.heads, -1, block_size_kv, v_dec.shape[-1])
            pair_bias_for_attn_dec = pair_bias.view(num_diff_samples, attn_layer.heads, -1, block_size_q, block_size_kv)

            # SDPA (Explicit Matmul/Softmax)
            attn_weights_dec = torch.matmul(q_block_dec * ATTN_SCALE_FROM_TRACE, k_block_dec.transpose(-1, -2))
            attn_weights_dec = attn_weights_dec + pair_bias_for_attn_dec
            attn_weights_dec = F.softmax(attn_weights_dec, dim=-1)
            attn_output_block_dec = torch.matmul(attn_weights_dec, v_block_dec)

            # Output proj + Gate
            attn_output_dec = attn_output_block_dec.permute(0, 2, 3, 1, 4).reshape(num_diff_samples, num_atoms, -1)
            _attn_out_proj_w_dec = attn_layer.out_proj.weight
            _attn_out_proj_b_dec = attn_layer.out_proj.bias
            attn_output_proj_dec = F.linear(attn_output_dec, _attn_out_proj_w_dec.t()) # Project output
            attn_output_plus_bias_dec = attn_output_proj_dec + _attn_out_proj_b_dec
            gate_dec = torch.sigmoid(attn_output_plus_bias_dec)
            atom_s_dec = residual + attn_output_dec * gate_dec # Multiply original attn output by gate

            # --- Transition Sub-block (Decoder) ---
            residual = atom_s_dec
            # AdaLN norm
            _trans_ln_s_merged_w_dec = trans_layer.ada_ln.lin_s_merged.weight
            scale_shift_trans_dec = F.linear(atom_s_cond_dec, _trans_ln_s_merged_w_dec.t())
            scale_trans_dec, shift_trans_dec = torch.chunk(scale_shift_trans_dec, c4, dim=-1)
            atom_s_norm_dec = F.layer_norm(atom_s_dec, [atom_s_dec.shape[-1]], eps=HIGH_EPS_LAYER_NORM) # No weight/bias
            atom_s_norm_dec = atom_s_norm_dec * (scale_trans_dec + c1) + shift_trans_dec

            # Gated MLP
            _trans_lin_a_w_dec = trans_layer.linear_a_nobias_double.weight
            _trans_lin_b_w_dec = trans_layer.linear_b_nobias.weight
            _trans_lin_s_w_dec = trans_layer.linear_s_biasinit_m2.weight
            _trans_lin_s_b_dec = trans_layer.linear_s_biasinit_m2.bias
            mlp_ab_dec = F.linear(atom_s_norm_dec, _trans_lin_a_w_dec.t())
            mlp_a_dec, mlp_b_dec = torch.chunk(mlp_ab_dec, c4, dim=-1)
            mlp_hidden_dec = F.silu(mlp_a_dec) * mlp_b_dec
            mlp_out_dec = F.linear(mlp_hidden_dec, _trans_lin_b_w_dec.t())
            gate_trans_cond_dec = F.linear(atom_s_cond_dec, _trans_lin_s_w_dec.t(), _trans_lin_s_b_dec)
            gate_trans_dec = torch.sigmoid(gate_trans_cond_dec)
            trans_output_dec = mlp_out_dec * gate_trans_dec
            atom_s_dec = residual + trans_output_dec

            atom_s_dec = atom_s_dec * atom_single_mask_expanded.unsqueeze(-1).float()

        # --- 5. Position Updates (Using module call) ---
        pos_updates = atom_attention_decoder.to_pos_updates(atom_s_dec) # Implicit LN + Linear

        # --- 6. Final Denoising Step (Explicit ops) ---
        denom = sigma_sq + c3
        scale_updates = (c6 * sigma_bc) * (denom**(-0.5))
        scale_coords = c3 / denom
        pos_updates_bc = pos_updates.unsqueeze(0)
        denoised_coords = (atom_noised_coords * scale_coords) + (pos_updates_bc * scale_updates)
        final_pos = denoised_coords.squeeze(0) # [5, 5888, 3]

        return final_pos