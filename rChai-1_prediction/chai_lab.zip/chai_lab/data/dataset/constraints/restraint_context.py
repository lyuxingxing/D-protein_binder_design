# Copyright (c) 2024 Chai Discovery, Inc.
# Licensed under the Apache License, Version 2.0.
# See the LICENSE file for details.

import logging
from dataclasses import asdict, dataclass

import numpy as np
from torch import Tensor
from typing_extensions import assert_never
from concurrent.futures import ThreadPoolExecutor

from chai_lab.data import residue_constants as rc
from chai_lab.data.dataset.structure.chain import Chain
from chai_lab.data.features.generators.docking import (
    RestraintGroup as DockingRestraint,
)
from chai_lab.data.features.generators.token_dist_restraint import (
    RestraintGroup as ContactRestraint,
)
from chai_lab.data.features.generators.token_pair_pocket_restraint import (
    RestraintGroup as PocketRestraint,
)
from chai_lab.data.parsing.restraints import (
    PairwiseInteraction,
    PairwiseInteractionType,
)
from chai_lab.utils.typing import typecheck, Int, UInt8

logger = logging.getLogger(__name__)


@typecheck
@dataclass
class RestraintContext:
    docking_restraints: list[DockingRestraint] | None
    contact_restraints: list[ContactRestraint] | None
    pocket_restraints: list[PocketRestraint] | None

    def __str__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"\n\tdocking_constraints {self.docking_restraints})"
            f"\n\tcontact_constraints {self.contact_restraints}"
            f"\n\tpocket_constraints {self.pocket_restraints}\n)"
        )

    def pad(self, *args, **kwargs) -> "RestraintContext":
        # No-op
        return RestraintContext(
            docking_restraints=self.docking_restraints,
            contact_restraints=self.contact_restraints,
            pocket_restraints=self.pocket_restraints,
        )

    def to_dict(self) -> dict[str, list[dict | None]]:
        return dict(
            docking_constraints=[asdict(c) for c in self.docking_restraints]
            if self.docking_restraints is not None
            else [None],
            contact_constraints=[asdict(c) for c in self.contact_restraints]
            if self.contact_restraints is not None
            else [None],
            pocket_constraints=[asdict(c) for c in self.pocket_restraints]
            if self.pocket_restraints is not None
            else [None],
        )

    @classmethod
    def empty(cls) -> "RestraintContext":
        return cls(
            docking_restraints=None,
            contact_restraints=None,
            pocket_restraints=None,
        )


def _is_cropped(
    chains: list[Chain],
    crop_idces: list[Tensor],
):
    return not all(
        [chain.num_tokens == len(crop) for chain, crop in zip(chains, crop_idces)]
    )


def renumber_array(array):
    tracer = array[0]
    indexer = array[0]
    for idx, element in enumerate(array):
        if element != tracer:
            tracer = element
            indexer += 1
        array[idx] = indexer


@typecheck
def load_manual_restraints_for_chai1(
    chains: list[Chain],
    crop_idces: list[Tensor] | None,
    provided_constraints: list[PairwiseInteraction],
    token_residue_index: Int[Tensor, "n_tokens"],
    residue_names: list[str],
    atom_token_index: Int[Tensor, "n_atoms"],
    atom_ref_name: list[str],
) -> RestraintContext:
    """Load constraints from manual specification."""
    if len(chains) == 0 or len(provided_constraints) == 0:
        return RestraintContext.empty()
    assert crop_idces is None or not _is_cropped(chains, crop_idces)

    # Precompute necessary mappings
    unique_resnames, resid_1st = np.unique(residue_names, return_index=True)
    unique_resnames_to_resid_1st = {i: j for i, j in zip(unique_resnames, resid_1st) if i not in rc.restype_3to1}
    atom_ref_name_np = np.array(atom_ref_name)
    non_repetitive_token_residue_index = np.array(token_residue_index)
    renumber_array(non_repetitive_token_residue_index)
    _shrink_atom_token_index, original_index_in_atom_token_index = np.unique(atom_token_index, return_index=True)

    # Precompute res_atom_idx_dic for all relevant residues
    res_atom_idx_dic = {}
    residues_to_compute = set()

    for constraint in provided_constraints:
        if constraint.connection_type != PairwiseInteractionType.CONTACT:
            continue
        res_idxA_name = rc.restype_1to3_with_x.get(constraint.res_idxA_name, constraint.res_idxA_name)
        res_idxB_name = rc.restype_1to3_with_x.get(constraint.res_idxB_name, constraint.res_idxB_name)
        if constraint.atom_nameA and res_idxA_name in unique_resnames_to_resid_1st:
            residues_to_compute.add(res_idxA_name)
        if constraint.atom_nameB and res_idxB_name in unique_resnames_to_resid_1st:
            residues_to_compute.add(res_idxB_name)

    for res_name in residues_to_compute:
        res_idx_1st = unique_resnames_to_resid_1st[res_name].item()
        mask = non_repetitive_token_residue_index == non_repetitive_token_residue_index[res_idx_1st]
        atom_indices = original_index_in_atom_token_index[mask]
        atom_names = atom_ref_name_np[atom_indices]
        res_atom_idx_dic[res_name] = {name: idx for idx, name in enumerate(atom_names)}

    # Parallel processing of constraints
    def process_constraint(constraint):
        res_idxA_name = rc.restype_1to3_with_x.get(constraint.res_idxA_name, constraint.res_idxA_name)
        res_idxB_name = rc.restype_1to3_with_x.get(constraint.res_idxB_name, constraint.res_idxB_name)

        match constraint.connection_type:
            case PairwiseInteractionType.COVALENT:
                return None
            case PairwiseInteractionType.CONTACT:
                res_atom_idxA, res_atom_idxB = 1, 1
                if constraint.atom_nameA and res_idxA_name in res_atom_idx_dic:
                    res_atom_idxA = res_atom_idx_dic[res_idxA_name].get(constraint.atom_nameA, 1)
                if constraint.atom_nameB and res_idxB_name in res_atom_idx_dic:
                    res_atom_idxB = res_atom_idx_dic[res_idxB_name].get(constraint.atom_nameB, 1)
                return ContactRestraint(
                    left_residue_subchain_id=constraint.chainA,
                    right_residue_subchain_id=constraint.chainB,
                    left_residue_index=constraint.res_idxA_pos - 1,
                    right_residue_index=constraint.res_idxB_pos - 1,
                    left_residue_name=res_idxA_name,
                    right_residue_name=res_idxB_name,
                    distance_threshold=constraint.max_dist_angstrom,
                    res_atom_idxA=res_atom_idxA,
                    res_atom_idxB=res_atom_idxB,
                )
            case PairwiseInteractionType.POCKET:
                return PocketRestraint(
                    pocket_chain_subchain_id=constraint.chainA,
                    pocket_token_subchain_id=constraint.chainB,
                    pocket_token_residue_index=constraint.res_idxB_pos - 1,
                    pocket_token_residue_name=res_idxB_name,
                    pocket_distance_threshold=constraint.max_dist_angstrom,
                )
            case _:
                assert_never(constraint.connection_type)

    # Use ThreadPoolExecutor for parallel processing
    with ThreadPoolExecutor(max_workers=16) as executor:
        results = list(executor.map(process_constraint, provided_constraints))

    # Collect results
    contact_constraints = []
    pocket_constraints = []
    for result in results:
        if isinstance(result, ContactRestraint):
            contact_constraints.append(result)
        elif isinstance(result, PocketRestraint):
            pocket_constraints.append(result)

    logger.info(f"Loaded {len(contact_constraints) + len(pocket_constraints)} restraints")

    return RestraintContext(
        docking_restraints=None,
        contact_restraints=contact_constraints if contact_constraints else None,
        pocket_restraints=pocket_constraints if pocket_constraints else None,
    )